The Most Complete Amiibo Set (MCAS for short) is a collection of clean binary dumps of the NTAG215s contained inside of Nintendo amiibo figures, cards and plushes. We also include the key file(s) needed to decrypt or encrypt your own amiibo bins with suitable software. (Such as TagMo, Ally, Amiitool, Amiiboss, etc.)

Dumps included in MCAS are straight dumps of retail amiibo, which means they are encrypted bins and should all be free of any user saved data, and in most cases, were dumped straight out of being removed from retail packaging.

MCAS is primarily hosted on archive.org for preservation purposes.
Please support official amiibo releases!

The latest MCAS is always able to be found at this URL:
https://archive.org/search?query=Most+Complete+Amiibo+Set&sort=-publicdate&and%5B%5D=subject%3A%22nfc%22&and%5B%5D=subject%3A%22amiibo%22

Special thanks to everyone who has helped with this project. (You know who you are!)